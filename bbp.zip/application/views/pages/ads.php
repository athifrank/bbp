		<div class="add_panel">           
            <script type="text/javascript">
			<!--
			google_ad_client = "ca-pub-7518834356735780";
			/* bbpad */
			google_ad_slot = "3279796495";
			google_ad_width = 120;
			google_ad_height = 600;
			//-->
			</script>
			<script type="text/javascript" src="<?=base_url();?>assets/js/show_ads.js"></script>
      	 </div>