<!----- Header_1 begins ----->
<div id="header_1">
    <div class="menu_1">
        <a href="<?=site_url();?>index">Home</a>|
        <a href="<?=site_url();?>login">Signin</a>|
        <a href="<?=site_url();?>register">Register</a>
    </div>
    <div class="menu_2">
		<a href="<?=site_url();?>contactus">Contact Us</a>
    </div>
</div>
<!----- Header_1 ends ----->

<!----- Header_2 begins ----->
<div id="header_2" class="wrapper">
    <div class="logo"><img src="<?=base_url();?>assets/images/logo.png" /></div>
    <div class="menu">
        <a href="<?=site_url();?>pass" >Post Your Property</a>|
        <a href="<?=site_url();?>knowledge_house/index">Knowledge House</a>|
      <a href="<?=site_url();?>property_documents">Property Documents</a>|
        <a href="<?=site_url();?>news">News</a>
    </div>
</div>
<!----- Header_2 ends ----->