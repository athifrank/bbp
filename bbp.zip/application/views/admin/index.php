<?php 
	header("location: ../accounts/index1.php");
?>
