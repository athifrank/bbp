        <div class="username">User : <?php echo $_SESSION['name'];?></div>
        <a href="#" >Home Page</a>|
        <a href="#">Main menu disabled in this page</a>|
        <a href="#" >Logout</a>