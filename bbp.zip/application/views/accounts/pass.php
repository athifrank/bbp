<?php 
		session_start();
		if (!(isset($_SESSION['user']) && $_SESSION['user'] != '')) header ("Location: index.php");
		else header ("Location: add_property.php");
?>